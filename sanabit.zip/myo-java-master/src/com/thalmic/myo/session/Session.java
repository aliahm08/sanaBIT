package com.thalmic.myo.session;

import java.util.*;


public class Session {
	private User user;
	private int sessionID;
	private ArrayList<Double> list_rollW;
	private ArrayList<Double> list_pitchW;
	private ArrayList<Double> list_yawW;
	private ArrayList<byte[]> emgData;
	public Session(String name, int id){
		user = new User(name, id);
		list_rollW = new ArrayList<Double>();
		list_pitchW= new ArrayList<Double>();
		list_yawW=new ArrayList<Double>();
		setEmgData(new ArrayList<byte[]>());
	}
	
	

	public User getUser() {
		return user;
	}

	public int getSessionID() {
		return sessionID;
	}
	
	
	public int getAverage(){
		//This has the average for all the data points at each sensor
		return 0;
	}

	public ArrayList<Double> getList_rollW() {
		return list_rollW;
	}

	public ArrayList<Double> getList_pitchW() {
		return list_pitchW;
	}

	public ArrayList<Double> getList_yawW() {
		return list_yawW;
	}

	public ArrayList<byte[]> getEmgData() {
		return emgData;
	}

	public void setEmgData(ArrayList<byte[]> emgData) {
		this.emgData = emgData;
	}
	
	

}

package com.thalmic.myo.session;

public class User {
	private String name;
	private int id;
	private int numberOfSessions = 0;
	
	public User(String name, int id){
		this.name = name;
		this.id = id;
	}

	public int getNumberOfSessions() {
		return numberOfSessions;
	}

	public void setNumberOfSessions(int numberOfSessions) {
		this.numberOfSessions = numberOfSessions;
	}

	public String getName() {
		return name;
	}

	public int getId() {
		return id;
	}
	
}

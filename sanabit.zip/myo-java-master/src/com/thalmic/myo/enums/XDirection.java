package com.thalmic.myo.enums;

public enum XDirection {
    X_DIRECTION_TOWARDS_WRIST,
    X_DIRECTION_TOWARDS_ELBOW,
    X_DIRECTION_UNKNOWN
}
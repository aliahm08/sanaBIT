package com.thalmic.myo.enums;

public enum Arm {
    ARM_LEFT,
    ARM_RIGHT,
    ARM_UNKNOWN
}
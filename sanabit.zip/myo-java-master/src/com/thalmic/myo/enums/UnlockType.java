package com.thalmic.myo.enums;

public enum UnlockType {
    UNLOCK_TIMED,
    UNLOCK_HOLD
}
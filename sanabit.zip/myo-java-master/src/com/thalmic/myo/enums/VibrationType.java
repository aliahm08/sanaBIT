package com.thalmic.myo.enums;

public enum VibrationType {
    VIBRATION_SHORT,
    VIBRATION_MEDIUM,
    VIBRATION_LONG
}

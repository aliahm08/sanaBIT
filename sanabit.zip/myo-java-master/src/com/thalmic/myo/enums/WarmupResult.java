package com.thalmic.myo.enums;

public enum WarmupResult {
	WARMUP_RESULT_UNKNOWN, WARMUP_RESULT_SUCCESSFUL, WARMUP_RESULT_FAILED_TIMEOUT;
}
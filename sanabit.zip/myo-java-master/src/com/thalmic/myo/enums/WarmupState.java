package com.thalmic.myo.enums;

public enum WarmupState {
	WARMUP_STATE_UNKNOWN, WARMUP_STATE_COLD, WARMUP_STATE_WARM;
}
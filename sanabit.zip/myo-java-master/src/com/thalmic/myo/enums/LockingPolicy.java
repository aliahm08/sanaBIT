package com.thalmic.myo.enums;

public enum LockingPolicy {
    LOCKING_POLICY_NONE,
    LOCKING_POLICY_STANDARD
}

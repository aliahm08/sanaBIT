package com.thalmic.myo.enums;

public enum StreamEmgType {
	STREAM_EMG_DISABLED, STREAM_EMG_ENABLED
}
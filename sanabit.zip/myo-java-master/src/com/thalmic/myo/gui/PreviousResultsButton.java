package com.thalmic.myo.gui;

import javax.swing.JButton;

public class PreviousResultsButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PreviousResultsButton(){
		setText("History");
	}

}

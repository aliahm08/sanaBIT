package com.thalmic.myo.gui;

import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JPanel;

public class History extends JPanel {

	private BackButton back;
	public History(){
		back = new BackButton();
		back.setBounds(0, 0, 30, 30);
		add(back);
		setLayout(null);
		setBackground(Color.white);
		setBounds(0, 0, 700, 700);
	}
	public BackButton getBack() {
		return back;
	}
	

	
}

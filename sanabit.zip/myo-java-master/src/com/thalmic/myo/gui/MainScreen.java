package com.thalmic.myo.gui;

import javax.swing.*;

public class MainScreen extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private WelcomeScreen screen1;
	private ClientScreen screen2;
	private TestScreen screen3;
	private History screen4;
	private Exercise screen5;
	private int number;
	public MainScreen() {
		screen1 = new WelcomeScreen();
		screen1.setBounds(0, 0,700,700);
		getContentPane().add(screen1);
		setLayout(null);
		setBounds(0, 0, 700, 700);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	
	public WelcomeScreen getScreen1() {
		return screen1;
	}

	public ClientScreen getScreen2() {
		return screen2;
	}

	public void setScreen2(ClientScreen screen2) {
		this.screen2 = screen2;
	}

	public TestScreen getScreen3() {
		return screen3;
	}

	public void setScreen3(TestScreen screen3) {
		this.screen3 = screen3;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public History getScreen4() {
		return screen4;
	}

	public void setScreen4(History screen4) {
		this.screen4 = screen4;
	}

	public Exercise getScreen5() {
		return screen5;
	}

	public void setScreen5(Exercise screen5) {
		this.screen5 = screen5;
	}
}

package com.thalmic.myo.gui;


import java.awt.*;

import javax.swing.JPanel;

public class ClientScreen extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private TestButton testNow;
	private PreviousResultsButton previous;
	private ExerciseButton exercise;
	private Skype skype;
	private InformationPad info;
	public ClientScreen() {
		testNow = new TestButton();
		testNow.setBounds(50,75,100,100);
		add(testNow);
		previous = new PreviousResultsButton();
		previous.setBounds(50, 200, 100, 100);
		add(previous);
		exercise = new ExerciseButton();
		exercise.setBounds(40, 325, 120, 100);
		add(exercise);
		skype = new Skype();
		skype.setBounds(75,550,75,75);
		add(skype);
		info = new InformationPad();
		info.setBounds(450, 0, 250, 700);
		add(info);
		setLayout(null);
		setBounds(0, 0, 700, 700);
		setBackground(Color.white);
				
	}

	public TestButton getTestNow() {
		return testNow;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public PreviousResultsButton getPrevious() {
		return previous;
	}

	public ExerciseButton getExercise() {
		return exercise;
	}

	public Skype getSkype() {
		return skype;
	}


}

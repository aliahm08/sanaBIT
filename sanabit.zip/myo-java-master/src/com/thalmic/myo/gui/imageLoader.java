package com.thalmic.myo.gui;

import java.io.InputStream;

public class imageLoader {
	
	public static InputStream load(String path){
		InputStream stream = imageLoader.class.getResourceAsStream(path);
		if (stream == null)
			stream = imageLoader.class.getResourceAsStream("/" + path);
		return stream;
	}

}

package com.thalmic.myo.gui;

import javax.swing.JButton;

public class SearchButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public SearchButton(){
		
	}

}

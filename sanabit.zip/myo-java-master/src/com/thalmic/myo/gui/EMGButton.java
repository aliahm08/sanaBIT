package com.thalmic.myo.gui;

import javax.swing.JButton;

public class EMGButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public EMGButton(){
		setText("EMG Analysis");
	}
}

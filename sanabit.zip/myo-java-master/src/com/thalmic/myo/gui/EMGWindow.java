package com.thalmic.myo.gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

import com.thalmic.myo.DeviceListener;
import com.thalmic.myo.Hub;
import com.thalmic.myo.Myo;
import com.thalmic.myo.enums.StreamEmgType;
import com.thalmic.myo.example.EmgDataCollector;
import com.thalmic.myo.session.Session;

public class EMGWindow extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Timer t = new Timer(5, this);
	private JLabel values;
	Hub hub = new Hub("com.example.emg-data-sample");
	Myo myo = hub.waitForMyo(10000);
	DeviceListener dataCollector = new EmgDataCollector();
	Session session;
	public EMGWindow(Session s){
		session = s;
		myo.setStreamEmg(StreamEmgType.STREAM_EMG_ENABLED);
		hub.addListener(dataCollector);
		values = new JLabel();
		values.setBounds(75, 75, 500, 200);
		add(values);
		setLayout(null);
		setBounds(0, 0, 700, 700);
		setBackground(Color.white);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		hub.run(1000 / 20);
		values.setText(dataCollector.toString());
		session.getEmgData().add(dataCollector.getEmgSample());
	}

}

package com.thalmic.myo.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import com.amazonaws.services.dynamodbv2.model.AttributeValue;

import myo.thalmic.myo.controller.Database;

public class InformationPad extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JLabel img;
	private JLabel nameL;
	private JLabel dob;
	private JLabel lastCheck;
	private JLabel noSessions;
	private JLabel email;
	private JLabel contactPhone;
	private JLabel currentCondition;
	private JTextArea dailyTasks;
	public InformationPad(){
		img = new JLabel(new ImageIcon("Sofia.jpg"));
		img.setBounds(0, 0, 166, 200);
		add(img);
		//d.dynamoDB.getItem("MyoSessionData", )
		nameL = new JLabel("Name: Sofia Vergara");
		nameL.setBounds(0,200, 250, 20);
		nameL.setFont(new Font("Courier",Font.BOLD,18));
		add(nameL);
		dob = new JLabel("DOB 07/10/1972");
		dob.setBounds(0,225, 250, 20);
		dob.setFont(new Font("Courier",Font.BOLD,18));
		add(dob);
		lastCheck = new JLabel("1 Day Ago");
		lastCheck.setBounds(0,250, 250, 20);
		lastCheck.setFont(new Font("Courier",Font.BOLD,18));
		add(lastCheck);
		noSessions = new JLabel("12 Sessions");
		noSessions.setBounds(0,275, 250, 20);
		noSessions.setFont(new Font("Courier",Font.BOLD,18));
		add(noSessions);
		currentCondition = new JLabel("FAIR");
		currentCondition.setBounds(0,325, 250, 40);
		currentCondition.setFont(new Font("Courier",Font.BOLD,40));
		add(currentCondition);
		email = new JLabel("satabin.fillangi@gmail.com");
		email.setBounds(0,365, 250, 20);
		email.setFont(new Font("Courier",Font.BOLD,18));
		add(email);
		contactPhone = new JLabel("1-800-GETWELL");
		contactPhone.setBounds(0,390, 250, 20);
		contactPhone.setFont(new Font("Courier",Font.BOLD,18));
		add(contactPhone);
		setLayout(null);
		setBounds(0, 0, 250, 700);
		
		
	}
	
	public JLabel getNameL() {
		return nameL;
	}
	public JLabel getDob() {
		return dob;
	}
	public JLabel getLastCheck() {
		return lastCheck;
	}
	public JLabel getNoSessions() {
		return noSessions;
	}
	public JLabel getEmail() {
		return email;
	}
	public JLabel getContactPhone() {
		return contactPhone;
	}
	public JLabel getCurrentCondition() {
		return currentCondition;
	}
	
}

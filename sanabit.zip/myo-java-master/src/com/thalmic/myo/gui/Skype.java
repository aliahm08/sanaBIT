package com.thalmic.myo.gui;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;

public class Skype extends JButton {
	BufferedImage img;

	public Skype() {
		try {
			img = ImageIO.read(imageLoader.load(""));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

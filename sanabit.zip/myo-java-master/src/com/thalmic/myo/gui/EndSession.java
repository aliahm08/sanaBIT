package com.thalmic.myo.gui;

import javax.swing.JButton;

public class EndSession extends JButton {
	
	public EndSession(){
		setText("End Session");
	}

}

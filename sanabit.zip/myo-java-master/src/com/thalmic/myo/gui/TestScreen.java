package com.thalmic.myo.gui;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class TestScreen extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel values;
	private JLabel values2;
	private BackButton back;
	private EndSession end;
	private Timer t;
	private GraphingData graphx;
	private GraphingData graphy;
	private GraphingData graphz;
	public TestScreen() {
		back = new BackButton();
		back.setBounds(0, 0,30,30);
		add(back);
		end=new EndSession();
		end.setBounds(300,550,150,30);
		add(end);
		values = new JLabel();
		values.setBounds(120, 5, 700, 22);
		values.setFont(new Font("Arial", Font.PLAIN, 22));
		add(values);
		values2 = new JLabel();
		values2.setBounds(120, 25, 700, 40);
		values2.setFont(new Font("Arial", Font.PLAIN, 16));
		add(values2);
		setLayout(null);
		setBounds(0, 0, 700, 700);
		setBackground(Color.white);
	}
	public JLabel getValues() {
		return values;
	}
	public Timer getT() {
		return t;
	}
	public void setT(Timer t) {
		this.t = t;
	}
	public JLabel getValues2() {
		return values2;
	}
	public void setValues2(JLabel values2) {
		this.values2 = values2;
	}
	public BackButton getBack() {
		return back;
	}
	public EndSession getEnd() {
		return end;
	}
	public GraphingData getGraphx() {
		return graphx;
	}
	public void setGraphx(GraphingData graph) {
		this.graphx = graph;
	}
	public GraphingData getGraphy() {
		return graphy;
	}
	public void setGraphy(GraphingData graphy) {
		this.graphy = graphy;
	}
	public GraphingData getGraphz() {
		return graphz;
	}
	public void setGraphz(GraphingData graphz) {
		this.graphz = graphz;
	}

}

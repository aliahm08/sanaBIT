package com.thalmic.myo.gui;

import java.awt.*;

import javax.swing.*;


public class WelcomeScreen extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private TextField username;
	private TextField userID;
	private SearchButton submit;
	private JLabel logo;
	public WelcomeScreen(){
		//Submit Button will be changed to a magnifying glass
		submit = new SearchButton();
		submit.setBounds(315, 500,150,70);
		submit.setIcon(new ImageIcon("magnifying.png"));
		submit.setContentAreaFilled(false);
		submit.setBorderPainted(false);
		submit.setOpaque(false);
		add(submit);
		
		logo = new JLabel(new ImageIcon("logo.jpg"));
		logo.setBounds(0, 0, 700, 700);
		
		//UserName input field
		username = new TextField("USERNAME");
		username.setEditable(true);
		username.setBounds(250,370,240,27);
		username.setForeground(Color.gray);
		username.setFont(new Font("Courier",Font.ITALIC,24));
		add(username);
		//UserID input field
		userID = new TextField("10101110");
		userID.setEditable(true);
		userID.setBounds(250,450,240,27);
		userID.setForeground(Color.gray);
		userID.setFont(new Font("Courier",Font.ITALIC,24));
		add(userID);
		
		setLayout(null);
		add(logo);
		setBounds(0, 0, 700, 700);
		setVisible(true);
		
	}
	public SearchButton getSubmit() {
		return submit;
	}
	public TextField getUsername() {
		return username;
	}
	public TextField getUserID() {
		return userID;
	}

}

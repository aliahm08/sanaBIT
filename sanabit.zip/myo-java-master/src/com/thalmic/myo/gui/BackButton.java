package com.thalmic.myo.gui;


import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;



public class BackButton extends JButton {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	BufferedImage img;
	public BackButton(){
		try {
			img =  ImageIO.read(imageLoader.load(""));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

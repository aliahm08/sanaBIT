package com.thalmic.myo.gui;

import javax.swing.JPanel;

public class Exercise extends JPanel {
	
}

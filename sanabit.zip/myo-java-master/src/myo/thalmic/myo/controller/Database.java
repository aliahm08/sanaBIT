package myo.thalmic.myo.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.DescribeTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.model.TableDescription;
import com.amazonaws.services.dynamodbv2.util.Tables;

public class Database {
	public static AmazonDynamoDBClient dynamoDB;

	public void init() throws Exception {

		AWSCredentials credentials = null;
		try {
			credentials = new ProfileCredentialsProvider("default")
					.getCredentials();
		} catch (Exception e) {
			throw new AmazonClientException(
					"Cannot load the credentials from the credential profiles file. "
							+ "Please make sure that your credentials file is at the correct "
							+ "location (C:\\Users\\Omar\\.aws\\credentials), and is in valid format.",
					e);
		}
		dynamoDB = new AmazonDynamoDBClient(credentials);
		Region usWest2 = Region.getRegion(Regions.US_WEST_2);
		dynamoDB.setRegion(usWest2);
	}

	public Database() {
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Map<String, AttributeValue> newItem(int userid,
			int sessionId, String username, String dob, int lastCheckedIn,
			String email, int noOfSessions, HashSet<String> roll,
			HashSet<String> pitch, HashSet<String> yaw) {
		Map<String, AttributeValue> item = new HashMap<String, AttributeValue>();
		item.put("UserId", new AttributeValue().withN(Integer.toString(userid)));
		item.put("SessionId",
				new AttributeValue().withN(Integer.toString(sessionId)));
		item.put("Username", new AttributeValue(username));
		item.put("DateOfBrith", new AttributeValue(dob));
		item.put("Email", new AttributeValue(email));
		item.put("LastCheckedIN",
				new AttributeValue().withN(Integer.toString(lastCheckedIn)));
		item.put("NumberOfSessions",
				new AttributeValue().withN(Integer.toString(noOfSessions)));
		item.put("RollingMotion", new AttributeValue().withSS(roll) );
		item.put("Pitch", new AttributeValue().withSS(pitch));
		item.put("Yaw", new AttributeValue().withSS(yaw));
		return item;
	}
	
}

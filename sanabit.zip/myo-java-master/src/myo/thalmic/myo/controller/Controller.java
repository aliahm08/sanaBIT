package myo.thalmic.myo.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.thalmic.myo.DeviceListener;
import com.thalmic.myo.Hub;
import com.thalmic.myo.Myo;
import com.thalmic.myo.example.DataCollector;
import com.thalmic.myo.gui.BackButton;
import com.thalmic.myo.gui.ClientScreen;
import com.thalmic.myo.gui.EndSession;
import com.thalmic.myo.gui.GraphingData;
import com.thalmic.myo.gui.History;
import com.thalmic.myo.gui.MainScreen;
import com.thalmic.myo.gui.PreviousResultsButton;
import com.thalmic.myo.gui.SearchButton;
import com.thalmic.myo.gui.TestButton;
import com.thalmic.myo.gui.TestScreen;
import com.thalmic.myo.session.Session;

public class Controller implements ActionListener {
	MainScreen window;

	Hub hub = new Hub("com.example.hello-myo");
	Myo myo = hub.waitForMyo(10000);
	DeviceListener dataCollector = new DataCollector();
	boolean testRunning = false;
	Session session;
	Database d = new Database();

	public Controller() {
		window = new MainScreen();
		addActionListener(window.getScreen1().getSubmit());
		hub.addListener(dataCollector);
	}

	public void addActionListener(JButton button) {
		button.addActionListener(this);
	}

	public void addAllListeners() {
		addActionListener(window.getScreen2().getTestNow());
		addActionListener(window.getScreen2().getPrevious());
		addActionListener(window.getScreen2().getExercise());
		addActionListener(window.getScreen2().getSkype());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource() instanceof SearchButton) {
			window.getScreen1().getUsername()
					.setText(window.getScreen1().getUsername().getText());
			window.getScreen1().getUserID()
					.setText(window.getScreen1().getUserID().getText());
			session = new Session(window.getScreen1().getUsername().getText(),
					Integer.parseInt(window.getScreen1().getUserID().getText()));
			window.remove(window.getScreen1());
			window.setScreen2(new ClientScreen());
			addAllListeners();
			window.getContentPane().add(window.getScreen2());
			window.revalidate();
			window.repaint();
		}

		if (e.getSource() instanceof TestButton) {
			window.remove(window.getScreen2());
			window.setScreen3(new TestScreen());
			window.getContentPane().add(window.getScreen3());
			window.setNumber(3);
			window.getScreen3().setT(new Timer(5, this));
			window.getScreen3().getT().start();
			testRunning = true;
			addActionListener(window.getScreen3().getBack());
			addActionListener(window.getScreen3().getEnd());
			window.revalidate();
			window.repaint();
		}
		if (testRunning) {
			hub.run(1000 / 20);
			session.getList_pitchW().add(new Double(dataCollector.getPitchW()));
			session.getList_rollW().add(new Double(dataCollector.getRollW()));
			session.getList_yawW().add(new Double(dataCollector.getYawW()));
			window.getScreen3().setGraphy(
					new GraphingData(session.getList_pitchW()));
			window.getScreen3().setGraphx(
					new GraphingData(session.getList_rollW()));
			window.getScreen3().setGraphz(
					new GraphingData(session.getList_yawW()));
			window.getScreen3().getGraphx().setBounds(0, 150, 200, 200);
			window.getScreen3().getGraphy().setBounds(0, 150, 200, 200);
			window.getScreen3().getGraphz().setBounds(0, 150, 200, 200);
			window.getScreen3().getValues().setText(dataCollector.toString());
			window.getScreen3()
					.getValues2()
					.setText(
							"          " + (int) dataCollector.getRollW()
									+ "                                     "
									+ (int) dataCollector.getPitchW()
									+ "                                     "
									+ (int) dataCollector.getYawW());
		}

		if (e.getSource() instanceof EndSession) {
			window.getScreen3().getT().stop();
			testRunning = false;
			end();
		}

		if (e.getSource() instanceof PreviousResultsButton) {
			window.remove(window.getScreen2());
			window.setScreen4(new History());
			window.getContentPane().add(window.getScreen4());
			window.setNumber(4);
			addActionListener(window.getScreen4().getBack());
			window.revalidate();
			window.repaint();
		}

		if (e.getSource() instanceof BackButton) {
			window.remove(screenNumber(window.getNumber()));
			window.setScreen2(new ClientScreen());
			window.getContentPane().add(window.getScreen2());
			window.setNumber(2);
			addAllListeners();
			if (testRunning)
				end();
			testRunning = false;
			window.revalidate();
			window.repaint();
		}

	}

	public HashSet<String> arrayConverter(ArrayList<Double> a) {
		HashSet<String> r = new HashSet<String>();
		for (int i = 0; i < a.size(); i++)
			r.add(a.get(i) + "");
		return r;
	}

	public void end() {
		try {
			Map<String, AttributeValue> item = d.newItem(5, 4, "O",
					"05/13/1995", 1, "mihilmy@yahoo.com", 5,
					arrayConverter(session.getList_pitchW()),
					arrayConverter(session.getList_rollW()),
					arrayConverter(session.getList_yawW()));
			PutItemRequest putItemRequest = new PutItemRequest(
					"MyoSessionData", item);
			Database.dynamoDB.putItem(putItemRequest);
		} catch (AmazonServiceException ase) {
			System.out
					.println("Caught an AmazonServiceException, which means your request made it "
							+ "to AWS, but was rejected with an error response for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out
					.println("Caught an AmazonClientException, which means the client encountered "
							+ "a serious internal problem while trying to communicate with AWS, "
							+ "such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
	}

	public JPanel screenNumber(int i) {
		JPanel p = null;
		switch (i) {
		case 3:
			p = window.getScreen3();
			break;
		case 4:
			p = window.getScreen4();
			break;
		case 5:
			p = window.getScreen5();
			break;
		}

		return p;
	}

	public static void main(String[] args) {
		try {
			new Controller();
		} catch (Exception e) {

		}
	}

}

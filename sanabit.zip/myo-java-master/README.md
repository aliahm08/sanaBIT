myo-java
========

Java Bindings for Myo
---------------------

Java language bindings for the Myo Developer Kit. The JNI libraries are all enclosed for OSX and Windows. 

If you need to build the Libraries yourself, please refer to this project: https://github.com/NicholasAStuart/myo-java-JNI-Library